from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path

from .models import WorkUnit, WorkUnitResult


@dataclass(frozen=True, slots=True)
class ComputationContext:
    """
    Per-invocation context.

    `workspace` is unique to the invocation and can be used to stage/download/
    unpack inputs and create result artifacts.
    """

    workspace: Path


class TileComputation(ABC):
    """
    Algorithm-specific work.

    Subclasses decide what frontier/context/final artifacts mean. The framework
    does not assume that they represent complete road features.
    """

    @abstractmethod
    def compute(
        self,
        work_unit: WorkUnit,
        context: ComputationContext,
    ) -> WorkUnitResult:
        raise NotImplementedError

from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any, Iterable, Mapping


@dataclass(frozen=True, slots=True)
class ArtifactRef:
    """
    Opaque reference to an artifact.

    `uri` can be file://, s3://, or any scheme understood by the computation /
    artifact-store integration. The orchestrator does not interpret its content.
    """

    uri: str
    format: str | None = None
    content_hash: str | None = None
    byte_size: int | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, order=True, slots=True)
class TileKey:
    """
    Logical grid cell.

    level=0 is the base grid. Each increment in level doubles the side length.
    x/y are coordinates at that level.
    """

    level: int
    x: int
    y: int

    def __post_init__(self) -> None:
        if self.level < 0:
            raise ValueError("tile level must be >= 0")

    def parent(self) -> "TileKey":
        return TileKey(level=self.level + 1, x=self.x // 2, y=self.y // 2)

    def is_neighbor(self, other: "TileKey", *, radius: int = 1) -> bool:
        if self.level != other.level:
            raise ValueError("neighbor checks require tiles at the same level")
        return (
            abs(self.x - other.x) <= radius
            and abs(self.y - other.y) <= radius
            and self != other
        )


def _stable_work_unit_id(
    *,
    generation: int,
    tile: TileKey,
    source_ids: Iterable[str],
) -> str:
    payload = "|".join(
        [
            str(generation),
            str(tile.level),
            str(tile.x),
            str(tile.y),
            *sorted(source_ids),
        ]
    )
    return sha256(payload.encode("utf-8")).hexdigest()[:24]


@dataclass(frozen=True, slots=True)
class WorkUnit:
    """
    A disjoint logical work unit for one generation.

    The semantic meaning of the artifacts is algorithm-specific.
    """

    id: str
    generation: int
    tile: TileKey
    frontier_artifacts: tuple[ArtifactRef, ...] = ()
    context_artifacts: tuple[ArtifactRef, ...] = ()
    source_work_unit_ids: tuple[str, ...] = ()

    @classmethod
    def initial(
        cls,
        *,
        tile: TileKey,
        frontier_artifacts: Iterable[ArtifactRef],
        context_artifacts: Iterable[ArtifactRef] = (),
        id: str | None = None,
    ) -> "WorkUnit":
        frontier = tuple(frontier_artifacts)
        context = tuple(context_artifacts)
        unit_id = id or _stable_work_unit_id(
            generation=0,
            tile=tile,
            source_ids=[a.uri for a in (*frontier, *context)],
        )
        return cls(
            id=unit_id,
            generation=0,
            tile=tile,
            frontier_artifacts=frontier,
            context_artifacts=context,
            source_work_unit_ids=(),
        )

    @classmethod
    def merged(
        cls,
        *,
        tile: TileKey,
        generation: int,
        children: Iterable["WorkUnitResult"],
    ) -> "WorkUnit":
        children = tuple(children)
        source_ids = tuple(sorted(result.work_unit.id for result in children))
        return cls(
            id=_stable_work_unit_id(
                generation=generation,
                tile=tile,
                source_ids=source_ids,
            ),
            generation=generation,
            tile=tile,
            frontier_artifacts=tuple(
                artifact
                for result in children
                for artifact in result.frontier_artifacts
            ),
            context_artifacts=tuple(
                artifact
                for result in children
                for artifact in result.context_artifacts
            ),
            source_work_unit_ids=source_ids,
        )


@dataclass(frozen=True, slots=True)
class WorkUnitResult:
    """
    Result of one computation.

    frontier_artifacts:
        Algorithm state that may still depend on information outside this work
        unit and therefore must participate in a later generation.

    context_artifacts:
        Resolved data/state that may still be required by frontier state.

    final_artifacts:
        Artifacts safe for the configured Finalizer to consume now.
    """

    frontier_artifacts: tuple[ArtifactRef, ...] = ()
    context_artifacts: tuple[ArtifactRef, ...] = ()
    final_artifacts: tuple[ArtifactRef, ...] = ()
    metrics: Mapping[str, Any] = field(default_factory=dict)
    work_unit: WorkUnit | None = None

    @property
    def has_frontier(self) -> bool:
        return bool(self.frontier_artifacts)

    def bind(self, work_unit: WorkUnit) -> "WorkUnitResult":
        if self.work_unit is not None and self.work_unit.id != work_unit.id:
            raise ValueError("result is already bound to a different work unit")
        return WorkUnitResult(
            frontier_artifacts=self.frontier_artifacts,
            context_artifacts=self.context_artifacts,
            final_artifacts=self.final_artifacts,
            metrics=self.metrics,
            work_unit=work_unit,
        )


@dataclass(frozen=True, slots=True)
class RunResult:
    final_artifacts: tuple[ArtifactRef, ...]
    generations: int
    work_units_executed: int
    generation_sizes: tuple[int, ...]

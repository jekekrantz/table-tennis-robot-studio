from __future__ import annotations

from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor
from collections.abc import Callable, Sequence
from typing import TypeVar

T = TypeVar("T")
R = TypeVar("R")


class Executor(ABC):
    @abstractmethod
    def map(self, fn: Callable[[T], R], items: Sequence[T]) -> list[R]:
        raise NotImplementedError


class InlineExecutor(Executor):
    """Useful for tests and debugging."""

    def map(self, fn: Callable[[T], R], items: Sequence[T]) -> list[R]:
        return [fn(item) for item in items]


class LocalExecutor(Executor):
    """
    Default local executor.

    Threads are intentionally used in the first implementation because they
    accept arbitrary Python computation objects without requiring them to be
    pickleable. A process-based executor can be added behind the same interface.
    """

    def __init__(self, *, max_workers: int | None = None) -> None:
        self.max_workers = max_workers

    def map(self, fn: Callable[[T], R], items: Sequence[T]) -> list[R]:
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            return list(pool.map(fn, items))

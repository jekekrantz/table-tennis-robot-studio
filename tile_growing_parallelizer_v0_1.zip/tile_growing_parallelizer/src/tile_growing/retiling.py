from __future__ import annotations

from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Sequence

from .models import TileKey, WorkUnit, WorkUnitResult


class RetileStrategy(ABC):
    @abstractmethod
    def retile(
        self,
        retained_results: Sequence[WorkUnitResult],
        *,
        next_generation: int,
    ) -> list[WorkUnit]:
        raise NotImplementedError


class QuadRetileStrategy(RetileStrategy):
    """
    Default 2x2 hierarchical coarsening.

    All retained results at level N are grouped by their level N+1 parent.
    Missing siblings are allowed: discarded/finalized data does not need to be
    recreated merely to make a physical 2x2 block.
    """

    def retile(
        self,
        retained_results: Sequence[WorkUnitResult],
        *,
        next_generation: int,
    ) -> list[WorkUnit]:
        by_parent: dict[TileKey, list[WorkUnitResult]] = defaultdict(list)

        for result in retained_results:
            if result.work_unit is None:
                raise ValueError("all results must be bound to their work unit")
            by_parent[result.work_unit.tile.parent()].append(result)

        return [
            WorkUnit.merged(
                tile=parent,
                generation=next_generation,
                children=children,
            )
            for parent, children in sorted(by_parent.items())
        ]

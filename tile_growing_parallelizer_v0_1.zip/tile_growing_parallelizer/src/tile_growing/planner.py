from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from collections.abc import Sequence

from .models import WorkUnit, WorkUnitResult
from .retiling import RetileStrategy


@dataclass(frozen=True, slots=True)
class Plan:
    next_work_units: tuple[WorkUnit, ...]

    @property
    def finished(self) -> bool:
        return not self.next_work_units


class Planner(ABC):
    @abstractmethod
    def plan_next(
        self,
        results: Sequence[WorkUnitResult],
        *,
        current_generation: int,
        retile_strategy: RetileStrategy,
    ) -> Plan:
        raise NotImplementedError


class DefaultPlanner(Planner):
    """
    Retains:
      - every work unit with frontier state;
      - context-only work units that neighbor a frontier work unit.

    The neighbor retention rule is the first implementation of the original
    "completed but still context relevant" idea. More sophisticated planners
    can replace this without changing the orchestrator.
    """

    def __init__(self, *, context_neighbor_radius: int = 1) -> None:
        if context_neighbor_radius < 0:
            raise ValueError("context_neighbor_radius must be >= 0")
        self.context_neighbor_radius = context_neighbor_radius

    def plan_next(
        self,
        results: Sequence[WorkUnitResult],
        *,
        current_generation: int,
        retile_strategy: RetileStrategy,
    ) -> Plan:
        if not results:
            return Plan(next_work_units=())

        bound = tuple(results)
        for result in bound:
            if result.work_unit is None:
                raise ValueError("planner requires bound results")
            if result.work_unit.generation != current_generation:
                raise ValueError("result generation does not match planner generation")

        frontier_results = tuple(r for r in bound if r.has_frontier)
        if not frontier_results:
            return Plan(next_work_units=())

        frontier_tiles = tuple(r.work_unit.tile for r in frontier_results)  # type: ignore[union-attr]

        retained: list[WorkUnitResult] = []
        for result in bound:
            unit = result.work_unit
            assert unit is not None

            if result.has_frontier:
                retained.append(result)
                continue

            if not result.context_artifacts:
                continue

            if any(
                unit.tile.is_neighbor(
                    frontier_tile,
                    radius=self.context_neighbor_radius,
                )
                for frontier_tile in frontier_tiles
            ):
                retained.append(result)

        next_units = retile_strategy.retile(
            retained,
            next_generation=current_generation + 1,
        )
        return Plan(next_work_units=tuple(next_units))

from __future__ import annotations

from collections.abc import Iterable, Sequence
from pathlib import Path
from tempfile import TemporaryDirectory

from .computation import ComputationContext, TileComputation
from .executor import Executor, LocalExecutor
from .finalizer import CollectingFinalizer, Finalizer
from .models import RunResult, WorkUnit, WorkUnitResult
from .planner import DefaultPlanner, Planner
from .retiling import QuadRetileStrategy, RetileStrategy


class TileGrowingParallelizer:
    """
    Public facade.

    Most callers only provide `computation`. Dependencies can be overridden
    independently when a particular problem/environment needs it.
    """

    def __init__(
        self,
        *,
        computation: TileComputation,
        executor: Executor | None = None,
        planner: Planner | None = None,
        retile_strategy: RetileStrategy | None = None,
        finalizer: Finalizer | None = None,
        max_generations: int = 64,
    ) -> None:
        if max_generations < 1:
            raise ValueError("max_generations must be >= 1")

        self.computation = computation
        self.executor = executor or LocalExecutor()
        self.planner = planner or DefaultPlanner()
        self.retile_strategy = retile_strategy or QuadRetileStrategy()
        self.finalizer = finalizer or CollectingFinalizer()
        self.max_generations = max_generations

    def run(self, initial_work_units: Iterable[WorkUnit]) -> RunResult:
        current = list(initial_work_units)
        self._validate_initial_units(current)

        generation_sizes: list[int] = []
        executed = 0
        completed_generations = 0

        for generation in range(self.max_generations):
            if not current:
                break

            self._validate_generation(current, generation)
            generation_sizes.append(len(current))

            results = self.executor.map(self._run_one, current)
            executed += len(current)
            completed_generations += 1

            bound_results = [
                result if result.work_unit is not None else result.bind(unit)
                for unit, result in zip(current, results, strict=True)
            ]

            for result in bound_results:
                assert result.work_unit is not None
                self.finalizer.accept(
                    result.final_artifacts,
                    source_work_unit=result.work_unit,
                )

            plan = self.planner.plan_next(
                bound_results,
                current_generation=generation,
                retile_strategy=self.retile_strategy,
            )

            if plan.finished:
                return RunResult(
                    final_artifacts=self.finalizer.finish(),
                    generations=completed_generations,
                    work_units_executed=executed,
                    generation_sizes=tuple(generation_sizes),
                )

            current = list(plan.next_work_units)

        if current:
            raise RuntimeError(
                "maximum number of generations reached with unresolved frontier "
                f"state remaining ({len(current)} work units)"
            )

        return RunResult(
            final_artifacts=self.finalizer.finish(),
            generations=completed_generations,
            work_units_executed=executed,
            generation_sizes=tuple(generation_sizes),
        )

    def _run_one(self, work_unit: WorkUnit) -> WorkUnitResult:
        with TemporaryDirectory(prefix=f"tile-growing-{work_unit.id}-") as tmp:
            context = ComputationContext(workspace=Path(tmp))
            result = self.computation.compute(work_unit, context)
            if not isinstance(result, WorkUnitResult):
                raise TypeError(
                    "computation.compute() must return WorkUnitResult, "
                    f"got {type(result)!r}"
                )
            return result.bind(work_unit)

    @staticmethod
    def _validate_initial_units(units: Sequence[WorkUnit]) -> None:
        if not units:
            return

        ids = [unit.id for unit in units]
        if len(ids) != len(set(ids)):
            raise ValueError("initial work-unit IDs must be unique")

        tiles = [unit.tile for unit in units]
        if len(tiles) != len(set(tiles)):
            raise ValueError("initial work units must have unique/disjoint TileKeys")

        if any(unit.generation != 0 for unit in units):
            raise ValueError("all initial work units must have generation=0")

        levels = {unit.tile.level for unit in units}
        if len(levels) != 1:
            raise ValueError("all initial work units must start at the same tile level")

    @staticmethod
    def _validate_generation(units: Sequence[WorkUnit], generation: int) -> None:
        if any(unit.generation != generation for unit in units):
            raise ValueError("work-unit generation mismatch")

        levels = {unit.tile.level for unit in units}
        if len(levels) > 1:
            raise ValueError("all work units in a generation must use the same tile level")

        tiles = [unit.tile for unit in units]
        if len(tiles) != len(set(tiles)):
            raise ValueError("work units in a generation must be spatially disjoint")


def run_tile_growing(
    initial_work_units: Iterable[WorkUnit],
    *,
    computation: TileComputation,
    executor: Executor | None = None,
    planner: Planner | None = None,
    retile_strategy: RetileStrategy | None = None,
    finalizer: Finalizer | None = None,
    max_generations: int = 64,
) -> RunResult:
    """Convenience API using the same defaults as TileGrowingParallelizer."""
    return TileGrowingParallelizer(
        computation=computation,
        executor=executor,
        planner=planner,
        retile_strategy=retile_strategy,
        finalizer=finalizer,
        max_generations=max_generations,
    ).run(initial_work_units)

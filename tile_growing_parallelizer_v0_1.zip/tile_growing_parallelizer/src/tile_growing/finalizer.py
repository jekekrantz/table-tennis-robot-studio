from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable

from .models import ArtifactRef, WorkUnit


class Finalizer(ABC):
    @abstractmethod
    def accept(
        self,
        artifacts: Iterable[ArtifactRef],
        *,
        source_work_unit: WorkUnit,
    ) -> None:
        raise NotImplementedError

    @abstractmethod
    def finish(self) -> tuple[ArtifactRef, ...]:
        raise NotImplementedError


class CollectingFinalizer(Finalizer):
    """
    Minimal default finalizer.

    It simply collects references. Production implementations can merge files,
    write manifests, upload outputs, etc.
    """

    def __init__(self) -> None:
        self._artifacts: list[ArtifactRef] = []

    def accept(
        self,
        artifacts: Iterable[ArtifactRef],
        *,
        source_work_unit: WorkUnit,
    ) -> None:
        del source_work_unit
        self._artifacts.extend(artifacts)

    def finish(self) -> tuple[ArtifactRef, ...]:
        return tuple(self._artifacts)

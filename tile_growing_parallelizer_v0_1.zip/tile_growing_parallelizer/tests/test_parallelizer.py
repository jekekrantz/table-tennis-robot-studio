from tile_growing import (
    ArtifactRef,
    DefaultPlanner,
    InlineExecutor,
    QuadRetileStrategy,
    TileComputation,
    TileGrowingParallelizer,
    TileKey,
    WorkUnit,
    WorkUnitResult,
)


def ref(name: str) -> ArtifactRef:
    return ArtifactRef(f"file:///{name}")


class ImmediateFinal(TileComputation):
    def compute(self, work_unit, context):
        del context
        return WorkUnitResult(final_artifacts=work_unit.frontier_artifacts)


def test_default_facade_finishes_in_one_generation():
    units = [
        WorkUnit.initial(
            tile=TileKey(0, 0, 0),
            frontier_artifacts=[ref("a")],
        ),
        WorkUnit.initial(
            tile=TileKey(0, 1, 0),
            frontier_artifacts=[ref("b")],
        ),
    ]

    result = TileGrowingParallelizer(
        computation=ImmediateFinal(),
        executor=InlineExecutor(),
    ).run(units)

    assert result.generations == 1
    assert result.work_units_executed == 2
    assert result.generation_sizes == (2,)
    assert {a.uri for a in result.final_artifacts} == {
        "file:///a",
        "file:///b",
    }


class ResolveAtLevelOne(TileComputation):
    def compute(self, work_unit, context):
        del context
        if work_unit.tile.level == 0:
            return WorkUnitResult(
                frontier_artifacts=work_unit.frontier_artifacts,
            )
        return WorkUnitResult(
            final_artifacts=work_unit.frontier_artifacts,
        )


def test_four_tiles_coarsen_into_one_parent():
    units = [
        WorkUnit.initial(
            tile=TileKey(0, x, y),
            frontier_artifacts=[ref(f"{x}-{y}")],
        )
        for y in range(2)
        for x in range(2)
    ]

    result = TileGrowingParallelizer(
        computation=ResolveAtLevelOne(),
        executor=InlineExecutor(),
    ).run(units)

    assert result.generations == 2
    assert result.generation_sizes == (4, 1)
    assert len(result.final_artifacts) == 4


def test_context_only_neighbor_is_retained():
    frontier = WorkUnit.initial(
        tile=TileKey(0, 0, 0),
        frontier_artifacts=[ref("frontier")],
    )
    context_neighbor = WorkUnit.initial(
        tile=TileKey(0, 1, 0),
        frontier_artifacts=[ref("input-neighbor")],
    )
    far_context = WorkUnit.initial(
        tile=TileKey(0, 4, 0),
        frontier_artifacts=[ref("input-far")],
    )

    results = [
        WorkUnitResult(
            frontier_artifacts=(ref("frontier-state"),),
        ).bind(frontier),
        WorkUnitResult(
            context_artifacts=(ref("neighbor-context"),),
        ).bind(context_neighbor),
        WorkUnitResult(
            context_artifacts=(ref("far-context"),),
        ).bind(far_context),
    ]

    plan = DefaultPlanner().plan_next(
        results,
        current_generation=0,
        retile_strategy=QuadRetileStrategy(),
    )

    all_context = {
        a.uri
        for unit in plan.next_work_units
        for a in unit.context_artifacts
    }

    assert "file:///neighbor-context" in all_context
    assert "file:///far-context" not in all_context


def test_work_unit_id_is_deterministic_after_merge():
    a = WorkUnit.initial(
        tile=TileKey(0, 0, 0),
        frontier_artifacts=[ref("a")],
    )
    b = WorkUnit.initial(
        tile=TileKey(0, 1, 0),
        frontier_artifacts=[ref("b")],
    )

    results1 = [
        WorkUnitResult(frontier_artifacts=(ref("a1"),)).bind(a),
        WorkUnitResult(frontier_artifacts=(ref("b1"),)).bind(b),
    ]
    results2 = list(reversed(results1))

    strategy = QuadRetileStrategy()
    first = strategy.retile(results1, next_generation=1)
    second = strategy.retile(results2, next_generation=1)

    assert len(first) == len(second) == 1
    assert first[0].id == second[0].id


def test_duplicate_initial_tiles_are_rejected():
    units = [
        WorkUnit.initial(
            tile=TileKey(0, 0, 0),
            frontier_artifacts=[ref("a")],
            id="a",
        ),
        WorkUnit.initial(
            tile=TileKey(0, 0, 0),
            frontier_artifacts=[ref("b")],
            id="b",
        ),
    ]

    try:
        TileGrowingParallelizer(
            computation=ImmediateFinal(),
            executor=InlineExecutor(),
        ).run(units)
    except ValueError as exc:
        assert "unique/disjoint TileKeys" in str(exc)
    else:
        raise AssertionError("expected ValueError")

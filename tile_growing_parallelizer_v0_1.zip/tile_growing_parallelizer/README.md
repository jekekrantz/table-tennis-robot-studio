# tile-growing-parallelizer

A first implementation of an iterative spatial parallelization framework based on:

- disjoint work units,
- algorithm-defined frontier state,
- resolved context,
- peeling finalized output,
- progressive tile growth/coarsening.

The framework deliberately does **not** use overlapping active halos.

## Minimal usage

```python
from tile_growing import (
    ArtifactRef,
    TileComputation,
    TileGrowingParallelizer,
    TileKey,
    WorkUnit,
    WorkUnitResult,
)

class MyComputation(TileComputation):
    def compute(self, work_unit, context):
        # Read/stage work_unit.frontier_artifacts and
        # work_unit.context_artifacts as needed.

        # Return algorithm-specific artifacts.
        return WorkUnitResult(
            frontier_artifacts=(),
            context_artifacts=(),
            final_artifacts=work_unit.frontier_artifacts,
        )

initial = [
    WorkUnit.initial(
        tile=TileKey(level=0, x=0, y=0),
        frontier_artifacts=[ArtifactRef("file:///data/tile-0-0.parquet")],
    ),
]

result = TileGrowingParallelizer(
    computation=MyComputation(),
).run(initial)

print(result.final_artifacts)
```

## Custom dependencies

```python
parallelizer = TileGrowingParallelizer(
    computation=my_computation,
    executor=my_executor,
    planner=my_planner,
    retile_strategy=my_retile_strategy,
    finalizer=my_finalizer,
)
```

The public facade owns the orchestration loop. `Planner`, `Executor`,
`RetileStrategy`, and `Finalizer` are replaceable policies/services.

## Current scope

This first version provides:

- a synchronous/threaded local executor,
- a default 2x2 quadtree-style retiler,
- context retention next to frontier work units,
- deterministic work-unit IDs,
- validation of generation/tile invariants,
- a collecting finalizer,
- extension points for other executors and retiling strategies.

It intentionally does not yet implement AWS Step Functions or S3. Those should
be thin environment-specific integrations around the same planner/computation
model rather than separate implementations of the algorithm.

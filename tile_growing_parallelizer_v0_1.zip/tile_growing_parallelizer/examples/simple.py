from tile_growing import (
    ArtifactRef,
    InlineExecutor,
    TileComputation,
    TileGrowingParallelizer,
    TileKey,
    WorkUnit,
    WorkUnitResult,
)


class ResolveAfterOneGrowth(TileComputation):
    """
    Tiny demonstration.

    Base tiles remain frontier. Once they have grown by one level, everything
    becomes final.
    """

    def compute(self, work_unit, context):
        del context

        if work_unit.tile.level == 0:
            return WorkUnitResult(
                frontier_artifacts=work_unit.frontier_artifacts,
                context_artifacts=work_unit.context_artifacts,
            )

        return WorkUnitResult(
            final_artifacts=(
                *work_unit.frontier_artifacts,
                *work_unit.context_artifacts,
            )
        )


initial = [
    WorkUnit.initial(
        tile=TileKey(level=0, x=x, y=y),
        frontier_artifacts=[ArtifactRef(f"file:///tile-{x}-{y}.parquet")],
    )
    for y in range(2)
    for x in range(2)
]

result = TileGrowingParallelizer(
    computation=ResolveAfterOneGrowth(),
    executor=InlineExecutor(),
).run(initial)

print(result)
